package za.ac.cput.listing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListingApplicationTests {

    @Test
    void contextLoads() {
    }

}
